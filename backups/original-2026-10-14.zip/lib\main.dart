import 'package:flutter/material.dart';

import 'src/general/config/colors.dart';
import 'src/general/config/config.dart';
import 'src/screens/views/all_request_details/screens/request_details_screen.dart';
import 'src/screens/views/all_requests/screens/all_request_screen.dart';
import 'src/screens/views/auth/login_screen.dart';
import 'src/screens/views/auth/register_screen.dart';
import 'src/screens/views/donor_registration/screens/donor_registration_screen.dart';
import 'src/screens/views/find_donor/screens/find_donor_screen.dart';
import 'src/screens/views/home/screens/home_screen.dart';
import 'src/screens/views/onboarding/splash_screen.dart';
import 'src/screens/views/profile/screens/profile_screen.dart';

void main() {
  runApp(const ValideiApp());
}

class ValideiApp extends StatelessWidget {
  const ValideiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: AppConfig.appName,
      theme: ThemeData(
        primaryColor: AppColor.redColor,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColor.redColor),
      ),
      // Vista inicial de desarrollo, sin requerir autenticacion Firebase.
      // La autenticacion real y el flujo de arranque quedan pendientes.
      initialRoute: HomeScreen.pageRoute,
      routes: {
        HomeScreen.pageRoute: (_) => const HomeScreen(),
        SplashScreen.pageRoute: (_) => const SplashScreen(),
        LoginScreen.pageRoute: (_) => const LoginScreen(),
        RegisterScreen.pageRoute: (_) => const RegisterScreen(),
        DonorRegistrationForm.pageRoute: (_) => const DonorRegistrationForm(),
        FindDonorScreen.pageRoute: (_) => const FindDonorScreen(),
        AllRequestScreen.pageRoute: (_) => const AllRequestScreen(),
        ProfileScreen.pageRoute: (_) => const ProfileScreen(),
        RequestDetailsScreen.pageRoute: (_) => const RequestDetailsScreen(),
      },
    );
  }
}
