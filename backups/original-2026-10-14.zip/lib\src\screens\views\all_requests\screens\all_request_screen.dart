
import 'package:flutter/material.dart';

import '../../../../general/utils/blank_space.dart';
import '../../../../general/utils/responsive.dart';
import '../../components/widgets/custom_appbar.dart';
import '../../components/widgets/custom_blood_filter_box.dart';
import '../../home/widgets/request_feed_item.dart';

class AllRequestScreen extends StatelessWidget {
  static const pageRoute = "/all-request";
  const AllRequestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(titlee: "Blood Requests", actionTrue: true),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(
            left: twentyPixelWidth(context),
            right: twentyPixelWidth(context),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              verticalSpace(twentyPixelHeight(context)),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'Filter',
                    style: const TextStyle(
                      color: Colors.black,
                      fontSize: 14,
                      fontFamily: 'PoppinsBold',
                      fontWeight: FontWeight.w700,
                    ),
                    textScaler: TextScaler.linear(ScaleSize.textScaleFactor(context)),
                  ),
                  horizontalSpace(twentyPixelWidth(context)*.25),
                  Image.asset("assets/icons/filter.png",
                  width: twelvePixelWidth(context)*2,
                  
                  ),

                ],
              ),
              verticalSpace(twentyPixelHeight(context)*.5),
              
              const CustomBloodFilterBox(),

              verticalSpace(twentyPixelHeight(context)*1),
              const CustomRequestFeedItem(),
              verticalSpace(twentyPixelHeight(context)*1),
              const CustomRequestFeedItem(),
              verticalSpace(twentyPixelHeight(context)*1),
              const CustomRequestFeedItem(),
              verticalSpace(twentyPixelHeight(context)*1),
              const CustomRequestFeedItem(),
              verticalSpace(twentyPixelHeight(context)*1),
              const CustomRequestFeedItem(),
              verticalSpace(twentyPixelHeight(context)*1),
              const CustomRequestFeedItem(),
              verticalSpace(twentyPixelHeight(context)*1.5),
            ],
          ),
        ),
      ),
    );
  }
}
