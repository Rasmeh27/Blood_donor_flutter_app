
import 'package:flutter/material.dart';

import '../../../../general/config/colors.dart';
import '../../../../general/utils/blank_space.dart';
import '../../../../general/utils/responsive.dart';
import '../../components/widgets/custom_appbar.dart';
import '../../components/widgets/custom_blood_group_box.dart';
import '../../components/widgets/custom_find_screen_item.dart';
import '../../components/widgets/custom_form_textfield.dart';
import '../../components/widgets/custom_red_btn.dart';
import '../../components/widgets/find_donor_date_picker.dart';


class DonorRegistrationForm extends StatelessWidget {
  static const pageRoute = "/donor-registraion";

  const DonorRegistrationForm({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
        actionTrue: true,
        titlee: "Donor Registration Form",
        
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const CustomFormText(
                textt: "Select Donor picture",
                isRequired: true,
              ),
              verticalSpace(twentyPixelHeight(context)),
              
              Center(child: Image.asset("assets/icons/profile.png",width: twentyPixelWidth(context)*5,)),
              verticalSpace(twentyPixelHeight(context)*.5),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset("assets/icons/camera_2.png",width: twentyPixelWidth(context)*1.5,),
                  horizontalSpace(twentyPixelWidth(context)),
                  Image.asset("assets/icons/gallary.png",width: twentyPixelWidth(context)*1.5,),
                ],
              ),
              verticalSpace(twentyPixelHeight(context)),
            const CustomFormText(textt: 'Name', isRequired: true),
            verticalSpace(twentyPixelHeight(context)*.5),
            CustomFormTextfield(hintTextt: "Jorge Perez",prefixFalse: false,),


            verticalSpace(twentyPixelHeight(context)),
            const CustomFormText(textt: 'Contact Number', isRequired: true),
            verticalSpace(twentyPixelHeight(context)*.5),
            CustomFormTextfield(hintTextt: "+18092249304",prefixFalse: false,),

            verticalSpace(twentyPixelHeight(context)),
            const CustomFormText(textt: "Blood Group", isRequired: true),
            verticalSpace(twentyPixelHeight(context)),
            
            Padding(
              padding:  EdgeInsets.only(
                left: twentyPixelWidth(context)*1.5,
                right: twentyPixelWidth(context)*1.5,
              ),
              child: const CustomBloodGroupBox(),
            ),

            verticalSpace(twentyPixelHeight(context)),

        
            const CustomFormText(textt: "Location", isRequired: true),
            verticalSpace(twentyPixelHeight(context)*.5),
            CustomFormTextfield(hintTextt: "Santo Domingo, RD",prefixFalse: true,prefixxIcon:Icons.location_on),

            verticalSpace(twentyPixelHeight(context)),
            const CustomFormText(textt: "Last Date of Donation", isRequired: true),
            verticalSpace(twentyPixelHeight(context)*.5),
            const FindDonorDatePicker(),
            verticalSpace(twentyPixelHeight(context)*1.5),
            const CustomRedBtn(
              textt: "Complete", 
              textColor: AppColor.whiteColor, 
              fillColor: AppColor.redColor,
              borderClr: Colors.transparent,
              ),

            
              
            ],
          ),
        ),
      ),
    );
  }
}

