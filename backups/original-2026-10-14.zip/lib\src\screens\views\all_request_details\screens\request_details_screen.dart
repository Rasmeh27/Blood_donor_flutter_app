
import 'package:flutter/material.dart';
import '../../../../general/config/colors.dart';
import '../../../../general/utils/blank_space.dart';
import '../../../../general/utils/responsive.dart';
import '../../components/widgets/custom_appbar.dart';
import '../widgets/custom_call_btn.dart';
import '../widgets/request_details_item.dart';

class RequestDetailsScreen extends StatelessWidget {
  static const pageRoute = "/request-details-screen";
  const RequestDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
        titlee: "Details",
        actionTrue: true,
        ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(
            left: twentyPixelWidth(context),
            right: twentyPixelWidth(context),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              verticalSpace(twentyPixelHeight(context) * 1.5),
              const RequestDetailsItem(
                titlee: "Blood want before",
                textt: "10 February 2024",
              ),
              const RequestDetailsItem(
                titlee: "Patient Name",
                textt: "Jorge Perez",
              ),
              
              const RequestDetailsItem(
                titlee: "Location ",
                textt: "Santo Domingo, RD",
              ),

              const RequestDetailsItem(
                titlee: "Blood Group",
                textt: "AB+",
              ),

              const RequestDetailsItem(
                titlee: "Contact Number",
                textt: "+18092249304",
              ),

              const RequestDetailsItem(
                titlee: "Cause",
                textt: "Cancer Patient",
              ),

              const RequestDetailsItem(
                titlee: "Number of Bags",
                textt: "2 Bags",
              ),

              const RequestDetailsItem(
                titlee: "Others",
                textt: "Need very urgent",
              ),

              verticalSpace(twentyPixelHeight(context)),
             const CustomCallButton(
              textt: "Call",
              textColor: AppColor.whiteColor,
              fillColor: AppColor.redColor,
              borderClr: Colors.transparent,
             ),
             verticalSpace(twentyPixelHeight(context)*.5),
             const CustomCallButton(
              textt: "Message",
              textColor: AppColor.redColor,
              fillColor: AppColor.whiteColor,
             )
            ],
          ),
        ),
      ),
    );
  }
}
