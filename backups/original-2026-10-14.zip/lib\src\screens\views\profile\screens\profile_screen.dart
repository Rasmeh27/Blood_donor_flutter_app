
import 'package:flutter/material.dart';

import '../../../../general/config/colors.dart';
import '../../../../general/utils/blank_space.dart';
import '../../../../general/utils/responsive.dart';
import '../../all_request_details/widgets/request_details_item.dart';
import '../../components/widgets/custom_appbar.dart';
import '../../components/widgets/custom_red_btn.dart';


class ProfileScreen extends StatelessWidget {
  static const pageRoute = "/profile";

  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(titlee: "Profile", actionTrue: true, profileFalse: true,),
      body: Padding(
        padding: EdgeInsets.symmetric(
            horizontal: twentyPixelWidth(context),
            vertical: twentyPixelHeight(context)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: twentyPixelWidth(context) * 6.5,
                    height: twentyPixelWidth(context) * 6.5,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(200),
                      border: Border.all(color: AppColor.redColor, width: 1),
                    ),
                  ),
                  Container(
                    width: twentyPixelWidth(context) * 6,
                    height: twentyPixelWidth(context) * 6,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(200),
                    ),
                    child: Image.asset("assets/images/profile.png"),
                  ),
                ],
              ),
            ),
            verticalSpace(twentyPixelHeight(context) * 2),
            const RequestDetailsItem(titlee: "Name", textt: "Jorge Perez"),
            const RequestDetailsItem(titlee: "Location", textt: "Santo Domingo, DN"),
            const RequestDetailsItem(titlee: "Gender", textt: "Male"),
            const RequestDetailsItem(titlee: "Blood Group", textt: "B+"),
            const RequestDetailsItem(titlee: "Mobile Number", textt: "+18092249304"),
            const Expanded(child: SizedBox()),
            const CustomRedBtn(
                textt: "Edit Profile",
                textColor: Colors.white,
                fillColor: AppColor.redColor,
                borderClr: Colors.transparent,
                ),

                verticalSpace(twentyPixelHeight(context)*.5)
          ],
        ),
      ),
    );
  }
}
