
import 'package:flutter/material.dart';

import '../../../../general/config/colors.dart';
import '../../../../general/utils/blank_space.dart';
import '../../../../general/utils/responsive.dart';
import '../../components/widgets/custom_appbar.dart';
import '../../components/widgets/custom_blood_group_box.dart';
import '../../components/widgets/custom_find_screen_item.dart';
import '../../components/widgets/custom_form_textfield.dart';
import '../../components/widgets/custom_gender_box.dart';
import '../../components/widgets/custom_red_btn.dart';
import '../../components/widgets/find_donor_date_picker.dart';


class FindDonorScreen extends StatefulWidget {
  static const pageRoute = '/find-donor';

  const FindDonorScreen({super.key});

  @override
  State<FindDonorScreen> createState() => _FindDonorScreenState();
}

class _FindDonorScreenState extends State<FindDonorScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
        titlee: "Request for Blood Donor",
        actionTrue: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(
            left: twentyPixelWidth(context),
            right: twentyPixelWidth(context),
            bottom: twentyPixelHeight(context),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              verticalSpace(twentyPixelHeight(context)),
              Center(
                child: Text(
                  "Patient Details",
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: AppColor.blackColor,
                      fontFamily: "Poppins"),
                  textScaler: TextScaler.linear(ScaleSize.textScaleFactor(context)),
                ),
              ),
              verticalSpace(twentyPixelHeight(context)),
              const CustomFormText(
                textt: "Choose Blood Group",
                isRequired: true,
              ),
              verticalSpace(twentyPixelHeight(context) * .5),
              Padding(
                padding:  EdgeInsets.only(
                  left: twentyPixelWidth(context)*1.5,
                  right: twentyPixelWidth(context)*1.5,
                ),
                child: const CustomBloodGroupBox(),
              ),

              verticalSpace(twentyPixelHeight(context)),
              const CustomFormText(
                textt: "Number of Bags",
                isRequired: true,
              ),
              verticalSpace(twentyPixelHeight(context) * .5),
              Row(
                children: [
                  Expanded(
                      child: CustomFormTextfield(
                    hintTextt: "3",
                    prefixFalse: false,
                  )),
                  horizontalSpace(twentyPixelWidth(context) * .5),
                  const Text(
                    "Bags",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      fontFamily: "Poppins",
                      color: AppColor.blackColor,
                    ),
                  )
                ],
              ),
              verticalSpace(twentyPixelHeight(context)),
              const CustomFormText(
                textt: "Contact Number",
                isRequired: true,
              ),
              verticalSpace(twentyPixelHeight(context) * .5),
              CustomFormTextfield(
                  hintTextt: "+880188888888", prefixxIcon: Icons.call),

              //Emergency Contact
              verticalSpace(twentyPixelHeight(context)),
              const CustomFormText(
                textt: "Emergency Contact",
                isRequired: true,
              ),
              verticalSpace(twentyPixelHeight(context) * .5),
              CustomFormTextfield(
                hintTextt: "+88019999999",
                prefixFalse: true,
                prefixxIcon: Icons.call,
              ),

              //Patient Nabe
              verticalSpace(twentyPixelHeight(context)),
              const CustomFormText(
                textt: "Patient Name",
                isRequired: true,
              ),
              verticalSpace(twentyPixelHeight(context) * .5),
              CustomFormTextfield(
                  hintTextt: "Jorge Perez",
                  prefixFalse: true,
                  prefixxIcon: Icons.person),

              //Case
              verticalSpace(twentyPixelHeight(context)),
              const CustomFormText(
                textt: "Case",
                isRequired: true,
              ),
              verticalSpace(twentyPixelHeight(context) * .5),
              CustomFormTextfield(
                  hintTextt: "Cancer Patient",
                  prefixFalse: false,
                  prefixxIcon: Icons.person),

              //Gender
              verticalSpace(twentyPixelHeight(context)),
              const CustomFormText(
                textt: "Gender",
                isRequired: false,
              ),
              verticalSpace(twentyPixelHeight(context) * 1.5),

              Padding(
                padding:  EdgeInsets.only(
                  left: twentyPixelWidth(context)*3,
                  right: twentyPixelWidth(context)*3,
                ),
                child: const CustomGenderBox(),
              ),

              verticalSpace(twentyPixelHeight(context) * 1.5),
              const CustomFormText(
                  textt: "Blood Need Before", isRequired: true),
              verticalSpace(twentyPixelHeight(context) * .5),

              const FindDonorDatePicker(),
              


              verticalSpace(twentyPixelHeight(context)),
              const CustomFormText(
                textt: "Others",
                isRequired: false,
              ),
              verticalSpace(twentyPixelHeight(context) * .5),
              CustomFormTextfield(
                  hintTextt: "Others",
                  prefixFalse: true,
                  prefixxIcon: Icons.person),
              verticalSpace(twentyPixelHeight(context) * 2),
              const CustomRedBtn(
                textt: "Find Donors",
                textColor: AppColor.whiteColor,
                fillColor: AppColor.redColor,
                borderClr: Colors.transparent,
              )
            ],
          ),
        ),
      ),
    );
  }
}
